
===================
corr.setupEsymLsym
===================

.. currentmodule:: nucleardatapy.corr.setupesymlsym

.. Don't include inherited members to keep the doc short
.. automodule:: nucleardatapy.corr.setup_EsymLsym
	:members:

Here are a set of figures which are produced with the Python sample: /nucleardatapy_sample/plots/plot_corr_setupEsymLsym.py

.. figure:: ../../../version-0.2/nucleardatapy_samples/plots/figs/plot_corr_setupEsymLsym.png
	:scale: 70 %
	:alt: map to buried treasure

	This figure shows the Esym,2 versus Lsym,2 correlation for the different constraints availble in the nucleardatapy toolkit.
