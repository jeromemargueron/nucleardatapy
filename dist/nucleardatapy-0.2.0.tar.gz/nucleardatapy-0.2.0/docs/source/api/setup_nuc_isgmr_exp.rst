
==================
nuc.setupISGMRExp
==================

.. currentmodule:: nucleardatapy.nucsetupISGMRExp

.. Don't include inherited members to keep the doc short
.. automodule:: nucleardatapy.nuc.setup_isgmr_exp
	:members:

Here are a set of figures which are produced with the Python sample: /nucleardatapy_sample/plots/plot_nuc_setupISGMRExp.py

.. figure:: ../../../version-0.2/nucleardatapy_samples/plots/figs/plot_nuc_setupISGMRExp.png
	:scale: 70 %
	:alt: map to buried treasure

	Experimental ISGMR energies available in the nucleardatapy toolkit.
