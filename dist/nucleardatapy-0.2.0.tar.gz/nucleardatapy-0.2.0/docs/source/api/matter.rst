======
Matter
======

.. toctree::
   :maxdepth: 2
    
   setup_matter_ffg
   setup_matter_micro
   setup_matter_micro_band
   setup_matter_micro_lp
   setup_matter_micro_gap
   setup_matter_micro_esym
   setup_matter_pheno
   setup_matter_pheno_esym
   setup_matter_hic