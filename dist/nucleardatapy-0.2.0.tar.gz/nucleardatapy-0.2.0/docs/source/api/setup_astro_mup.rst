
==============
astro.setupMup
==============

.. currentmodule:: nucleardatapy.astro.setupmup

.. Don't include inherited members to keep the doc short
.. automodule:: nucleardatapy.astro.setup_mup
	:members:

Here is a figure which is produced with the Python sample: /nucleardatapy_sample/plots/plot_astro_setupMup.py

.. figure:: ../../../version-0.2/nucleardatapy_samples/plots/figs/plot_astro_setupMup.png
	:scale: 70 %
	:alt: map to buried treasure

	The upper masses measured from GW observations. The different colors correspond to the different sources.

