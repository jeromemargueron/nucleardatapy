
==================
astro.setupMasses
==================

.. currentmodule:: nucleardatapy.astro.setupmasses

.. Don't include inherited members to keep the doc short
.. automodule:: nucleardatapy.astro.setup_masses
	:members:

Here is a figure which is produced with the Python sample: /nucleardatapy_sample/plots/plot_astro_setupMasses.py

.. figure:: ../../../version-0.2/nucleardatapy_samples/plots/figs/plot_astro_setupMasses.png
	:scale: 70 %
	:alt: map to buried treasure

	The masses measured for massive neutron stars is radio-astronomy. The different colors correspond to the different sources.

