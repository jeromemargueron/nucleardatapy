Astro
======

.. toctree::
   :maxdepth: 2

   setup_astro_gw
   setup_astro_masses
   setup_astro_mr
   setup_astro_mup
   setup_astro_mtov
