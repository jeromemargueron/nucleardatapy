

==================
hnuc.setupRE1LExp
==================

.. currentmodule:: nucleardatapy.nucsetupre1lexp

.. Don't include inherited members to keep the doc short
.. automodule:: nucleardatapy.hnuc.setup_re1L_exp
	:members:

Here are a set of figures which are produced with the Python sample: /nucleardatapy_sample/hnuc_setupRE1LExp_plot.py

.. figure:: ../../../version-0.2/nucleardatapy_samples/figs/plot_hnuc_setupRE1LExp.png
	:width: 70%
	:alt: map to buried treasure

