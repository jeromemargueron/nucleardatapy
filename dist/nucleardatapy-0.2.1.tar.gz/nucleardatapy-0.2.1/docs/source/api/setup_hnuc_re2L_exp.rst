

===============
hnuc.setupRE2LExp
===============

.. currentmodule:: nucleardatapy.nucsetupre2lexp

.. Don't include inherited members to keep the doc short
.. automodule:: nucleardatapy.hnuc.setup_re2L_exp
	:members:


