
Hyper-Nuclei
==========

.. toctree::
   :maxdepth: 2
    
   setup_hnuc_re1L_exp
   setup_hnuc_re1Xi_exp
   setup_hnuc_re2L_exp
   
Here is a figure which is produced with the Python sample: /nucleardatapy_sample/hnuc_setupChart_plot.py

.. figure:: ../../../version-0.2/nucleardatapy_samples/figs/plot_hnuc_setupChart.png
	:width: 70%
	:alt: map to buried treasure

