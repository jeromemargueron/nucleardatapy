

===================
hnuc.setupRE1XiExp
===================

.. currentmodule:: nucleardatapy.nucsetupre1xiexp

.. Don't include inherited members to keep the doc short
.. automodule:: nucleardatapy.hnuc.setup_re1Xi_exp
	:members:


