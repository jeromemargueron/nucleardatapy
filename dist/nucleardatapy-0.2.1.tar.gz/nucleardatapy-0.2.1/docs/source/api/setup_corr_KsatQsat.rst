

===================
corr.setupKsatQsat
===================

.. currentmodule:: nucleardatapy.corr.setupksatqsat

.. Don't include inherited members to keep the doc short
.. automodule:: nucleardatapy.corr.setup_KsatQsat
	:members:

Here are a set of figures which are produced with the Python sample: /nucleardatapy_sample/corr_setupKsatQsat_plot.py

.. figure:: ../../../version-0.2/nucleardatapy_samples/figs/plot_corr_setupKsatQsat.png
	:width: 70 %
	:alt: map to buried treasure

	This figure shows the Ksat versus Qsat correlation for the different constraints availble in the nucleardatapy toolkit.
