
import os

def create_folder_fig():
	#
	os.system('mkdir -p figs/')
	#