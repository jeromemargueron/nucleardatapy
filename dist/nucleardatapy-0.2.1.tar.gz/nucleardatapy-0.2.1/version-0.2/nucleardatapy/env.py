
#verb = True
verb = False

# verb_output = True
verb_output = False

verb_latex = True
#verb_latex = False
